import { useState } from "react";
import { AlertTriangle, Send } from "lucide-react";

const initial = { patient_name: "", age: "", symptoms: "", emergency_type: "Medical", latitude: "19.8762", longitude: "75.3433" };

export default function EmergencyForm({ onCreated }) {
  const [form, setForm] = useState(initial);
  const [loading, setLoading] = useState(false);
  const [localError, setLocalError] = useState("");
  const update = e => setForm({ ...form, [e.target.name]: e.target.value });

  async function submit(e) {
    e.preventDefault(); setLoading(true); setLocalError("");
    try {
      await onCreated({ ...form, age: form.age ? Number(form.age) : null, latitude: Number(form.latitude), longitude: Number(form.longitude) });
      setForm(initial);
    } catch (err) { setLocalError(err?.response?.data?.message || err.message || "Unable to create emergency"); }
    finally { setLoading(false); }
  }

  return <form className="panel form-panel" onSubmit={submit}>
    <div className="panel-title"><AlertTriangle size={20}/><div><h2>Register Emergency</h2><small>AI severity analysis on submission</small></div></div>
    {localError && <div className="form-error">{localError}</div>}
    <label>Patient name<input name="patient_name" value={form.patient_name} onChange={update} required placeholder="Patient name"/></label>
    <div className="two-col"><label>Age<input name="age" type="number" min="0" max="120" value={form.age} onChange={update} placeholder="Age"/></label><label>Emergency type<select name="emergency_type" value={form.emergency_type} onChange={update}><option>Medical</option><option>Cardiac</option><option>Stroke</option><option>Trauma</option><option>Accident</option><option>Pregnancy</option></select></label></div>
    <label>Symptoms<textarea name="symptoms" value={form.symptoms} onChange={update} required placeholder="Example: severe chest pain and breathing difficulty"/></label>
    <div className="two-col"><label>Latitude<input name="latitude" value={form.latitude} onChange={update} required/></label><label>Longitude<input name="longitude" value={form.longitude} onChange={update} required/></label></div>
    <button className="primary-btn" disabled={loading}><Send size={17}/>{loading ? "Creating..." : "Create Emergency"}</button>
  </form>;
}
