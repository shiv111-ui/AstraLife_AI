export default function StatCard({ title, value, icon, tone = "" }) {
  return <div className={`stat-card ${tone}`}><div className="stat-icon">{icon}</div><div><div className="stat-title">{title}</div><div className="stat-value">{value}</div></div></div>;
}
