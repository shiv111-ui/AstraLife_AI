import "leaflet/dist/leaflet.css";
import { useEffect, useMemo } from "react";
import {
  MapContainer,
  TileLayer,
  CircleMarker,
  Popup,
  Polyline,
  useMap,
} from "react-leaflet";

const DEFAULT_CENTER = [19.885, 75.34];

function toPoint(latitude, longitude) {
  const lat = Number(latitude);
  const lng = Number(longitude);

  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  if (lat < -90 || lat > 90 || lng < -180 || lng > 180) return null;

  return [lat, lng];
}

function MapViewport({ points, selectedPoint }) {
  const map = useMap();

  useEffect(() => {
    // Leaflet can calculate the container size incorrectly when the map is
    // rendered inside a grid/panel. Recalculate it after the DOM is painted.
    const timer = window.setTimeout(() => map.invalidateSize(), 100);
    return () => window.clearTimeout(timer);
  }, [map]);

  useEffect(() => {
    if (selectedPoint) {
      map.flyTo(selectedPoint, Math.max(map.getZoom(), 14), {
        animate: true,
        duration: 0.6,
      });
      return;
    }

    if (points.length > 0) {
      map.fitBounds(points, {
        padding: [35, 35],
        maxZoom: 14,
      });
    }
  }, [map, points, selectedPoint]);

  return null;
}

export default function LiveMap({
  ambulances = [],
  hospitals = [],
  selectedEmergency,
  corridor,
}) {
  const ambulancePoints = useMemo(
    () =>
      ambulances
        .map((a) => ({ item: a, point: toPoint(a.latitude, a.longitude) }))
        .filter(({ point }) => point),
    [ambulances]
  );

  const hospitalPoints = useMemo(
    () =>
      hospitals
        .map((h) => ({ item: h, point: toPoint(h.latitude, h.longitude) }))
        .filter(({ point }) => point),
    [hospitals]
  );

  const emergencyPoint = useMemo(
    () =>
      selectedEmergency
        ? toPoint(selectedEmergency.latitude, selectedEmergency.longitude)
        : null,
    [selectedEmergency]
  );

  const routePoints = useMemo(
    () =>
      Array.isArray(corridor?.route)
        ? corridor.route.map((p) => {
            if (!Array.isArray(p) || p.length < 2) return null;
            return toPoint(p[0], p[1]);
          }).filter(Boolean)
        : [],
    [corridor]
  );

  const allPoints = useMemo(
    () => [
      ...ambulancePoints.map(({ point }) => point),
      ...hospitalPoints.map(({ point }) => point),
      ...(emergencyPoint ? [emergencyPoint] : []),
      ...routePoints,
    ],
    [ambulancePoints, hospitalPoints, emergencyPoint, routePoints]
  );

  return (
    <MapContainer
      center={DEFAULT_CENTER}
      zoom={13}
      className="live-map"
      scrollWheelZoom={true}
      preferCanvas={true}
    >
      <TileLayer
        attribution="&copy; OpenStreetMap contributors"
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        maxZoom={19}
      />

      <MapViewport points={allPoints} selectedPoint={emergencyPoint} />

      {ambulancePoints.map(({ item: a, point }) => {
        const status = String(a.status || "").toUpperCase();
        const available = status === "AVAILABLE";

        return (
          <CircleMarker
            key={`ambulance-${a.id}`}
            center={point}
            radius={9}
            pathOptions={{
              color: available ? "#15803d" : "#1d4ed8",
              fillColor: available ? "#22c55e" : "#3b82f6",
              fillOpacity: 0.9,
              weight: 3,
            }}
          >
            <Popup>
              <strong>🚑 {a.code || a.vehicle_no || `Ambulance #${a.id}`}</strong>
              <br />
              Driver: {a.driver || a.driver_name || "N/A"}
              <br />
              Status: {a.status || "N/A"}
              <br />
              Coordinates: {point[0].toFixed(5)}, {point[1].toFixed(5)}
            </Popup>
          </CircleMarker>
        );
      })}

      {hospitalPoints.map(({ item: h, point }) => (
        <CircleMarker
          key={`hospital-${h.id}`}
          center={point}
          radius={10}
          pathOptions={{
            color: "#991b1b",
            fillColor: "#ef4444",
            fillOpacity: 0.9,
            weight: 3,
          }}
        >
          <Popup>
            <strong>🏥 {h.name}</strong>
            <br />
            Emergency beds: {h.emergency_beds ?? 0}
            <br />
            Coordinates: {point[0].toFixed(5)}, {point[1].toFixed(5)}
          </Popup>
        </CircleMarker>
      ))}

      {emergencyPoint && selectedEmergency && (
        <CircleMarker
          center={emergencyPoint}
          radius={11}
          pathOptions={{
            color: "#6d28d9",
            fillColor: "#a78bfa",
            fillOpacity: 0.95,
            weight: 4,
          }}
        >
          <Popup>
            <strong>🚨 Emergency #{selectedEmergency.id}</strong>
            <br />
            {selectedEmergency.patient_name}
            <br />
            Priority: {selectedEmergency.priority}
            <br />
            Coordinates: {emergencyPoint[0].toFixed(5)},{" "}
            {emergencyPoint[1].toFixed(5)}
          </Popup>
        </CircleMarker>
      )}

      {routePoints.length > 1 && (
        <Polyline
          positions={routePoints}
          pathOptions={{
            color: "#16a34a",
            weight: 7,
            opacity: 0.85,
          }}
        />
      )}
    </MapContainer>
  );
}
