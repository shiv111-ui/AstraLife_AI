import { useCallback, useEffect, useState } from "react";
import { Activity, Ambulance, Bed, Hospital, RefreshCw, Send, Siren, Wifi, MapPinned, ShieldCheck, Trash2 } from "lucide-react";
import StatCard from "./components/StatCard";
import EmergencyForm from "./components/EmergencyForm";
import LiveMap from "./components/LiveMap";
import {
  createEmergency, deleteEmergency, dispatchEmergency, getAmbulances, getDashboard,
  getEmergencies, getGreenCorridor, getHospitals, getPredictivePlacement,
} from "./api";
import "./styles.css";

const priorityClass = (value = "LOW") => String(value).toLowerCase();
const statusClass = (value = "") => String(value).toLowerCase().replaceAll("_", "-");

export default function App() {
  const [dashboard, setDashboard] = useState(null);
  const [ambulances, setAmbulances] = useState([]);
  const [hospitals, setHospitals] = useState([]);
  const [emergencies, setEmergencies] = useState([]);
  const [corridor, setCorridor] = useState(null);
  const [selectedEmergency, setSelectedEmergency] = useState(null);
  const [predictions, setPredictions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("System ready");
  const [error, setError] = useState("");
  const [deletingId, setDeletingId] = useState(null);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [d, a, h, e, p] = await Promise.all([
        getDashboard(), getAmbulances(), getHospitals(), getEmergencies(), getPredictivePlacement(),
      ]);
      setDashboard(d.data.data);
      setAmbulances(a.data.data);
      setHospitals(h.data.data);
      setEmergencies(e.data.data);
      setPredictions(p.data.data);
      setMessage("Live data synchronized");
    } catch (err) {
      setError(err?.response?.data?.message || "Unable to connect to backend. Start the backend on port 5000.");
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  async function handleCreated(payload) {
    const response = await createEmergency(payload);
    const emergency = response.data.data;
    setSelectedEmergency(emergency);
    setMessage(`Emergency #${emergency.id} created — ${emergency.priority} priority`);
    await loadData();
    try {
      const corridorResponse = await getGreenCorridor(emergency.id);
      setCorridor(corridorResponse.data.data);
    } catch { /* corridor is optional for a newly created emergency */ }
  }

  async function handleDispatch(id) {
    try {
      const response = await dispatchEmergency(id);
      setSelectedEmergency(response.data.data.emergency);
      const corridorResponse = await getGreenCorridor(id);
      setCorridor(corridorResponse.data.data);
      setMessage(`Ambulance ${response.data.data.ambulance.code} dispatched successfully`);
      await loadData();
    } catch (err) {
      setError(err?.response?.data?.message || "Dispatch failed");
    }
  }



  async function handleDeleteEmergency(id, patientName) {
    const confirmed = window.confirm(
      `Remove patient "${patientName}" (Emergency #${id})? This will permanently delete this emergency record.`
    );
    if (!confirmed) return;

    setDeletingId(id);
    setError("");
    try {
      await deleteEmergency(id);
      if (selectedEmergency?.id === id) {
        setSelectedEmergency(null);
        setCorridor(null);
      }
      setMessage(`Patient ${patientName} removed successfully`);
      await loadData();
    } catch (err) {
      setError(err?.response?.data?.message || "Unable to remove patient. Please try again.");
    } finally {
      setDeletingId(null);
    }
  }

  async function selectEmergency(item) {
    setSelectedEmergency(item);
    try {
      const response = await getGreenCorridor(item.id);
      setCorridor(response.data.data);
    } catch { setCorridor(null); }
  }

  const stats = dashboard || {
    ambulances: { total: 0, available: 0, busy: 0 },
    hospitals: { total: 0, emergency_beds: 0 },
    emergencies: { total: 0, active: 0 },
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <div>
          <div className="brand"><Siren size={27} /> ASTRALIFE <span>AI</span></div>
          <p>Intelligent Emergency Response &amp; Green Corridor Network</p>
        </div>
        <div className="online"><Wifi size={14} /> SYSTEM ONLINE</div>
      </header>

      <main className="content">
        <div className="page-heading">
          <div>
            <h1>Emergency Control Center</h1>
            <p>Every second saves a life — coordinate patients, ambulances, hospitals and traffic.</p>
          </div>
          <button className="refresh-btn" onClick={loadData} disabled={loading}>
            <RefreshCw size={16} className={loading ? "spin" : ""} /> Refresh
          </button>
        </div>

        {error && <div className="notice error">⚠ {error}</div>}
        {!error && <div className="notice"><ShieldCheck size={16} /> {message}</div>}

        <section className="stats-grid">
          <StatCard title="Total Ambulances" value={stats.ambulances.total ?? 0} icon={<Ambulance size={22} />} />
          <StatCard title="Available Now" value={stats.ambulances.available ?? 0} icon={<Activity size={22} />} tone="success" />
          <StatCard title="Active Emergencies" value={stats.emergencies.active ?? 0} icon={<Siren size={22} />} tone="danger" />
          <StatCard title="Emergency Beds" value={stats.hospitals.emergency_beds ?? 0} icon={<Bed size={22} />} tone="purple" />
        </section>

        <section className="main-grid">
          <div className="panel">
            <div className="panel-title"><MapPinned size={20} /><div><h2>Live Emergency Map</h2><small>Ambulance and hospital locations with simulated green corridor</small></div></div>
            <LiveMap ambulances={ambulances} hospitals={hospitals} selectedEmergency={selectedEmergency} corridor={corridor} />
            <div className="corridor-bar"><Activity size={17} /><strong>Green Corridor:</strong> {corridor ? `${corridor.signals?.length || 0} traffic signals prioritized` : "Select an emergency to activate route simulation"}<span>{corridor ? "ACTIVE" : "STANDBY"}</span></div>
          </div>
          <EmergencyForm onCreated={handleCreated} />
        </section>

        <section className="bottom-grid">
          <div className="panel">
            <div className="panel-title"><Siren size={20} /><div><h2>Emergency Queue</h2><small>{emergencies.length} registered cases</small></div></div>
            <div className="list">
              {emergencies.length === 0 && <div className="muted">No emergencies registered yet.</div>}
              {emergencies.map(item => (
                <div key={item.id} className={`emergency-row ${selectedEmergency?.id === item.id ? "selected" : ""}`} onClick={() => selectEmergency(item)}>
                  <div><strong>#{item.id} · {item.patient_name}</strong><small>{item.emergency_type} · {item.status}</small></div>
                  <span className={`priority ${priorityClass(item.priority)}`}>{item.priority}</span>
                  {item.status === "NEW" && <button className="dispatch-btn" onClick={(e) => { e.stopPropagation(); handleDispatch(item.id); }}><Send size={14} /> Dispatch</button>}
                  <button
                    type="button"
                    className="delete-btn"
                    title={`Remove ${item.patient_name}`}
                    aria-label={`Remove patient ${item.patient_name}`}
                    disabled={deletingId === item.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteEmergency(item.id, item.patient_name);
                    }}
                  >
                    <Trash2 size={14} /> {deletingId === item.id ? "Removing..." : "Remove"}
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="panel">
            <div className="panel-title"><Ambulance size={20} /><div><h2>Ambulance Fleet</h2><small>Live availability</small></div></div>
            <div className="list">
              {ambulances.map(a => <div className="simple-row" key={a.id}><div><strong>{a.code}</strong><small>{a.driver}</small></div><span className={`status-pill ${statusClass(a.status)}`}>{a.status}</span></div>)}
            </div>
          </div>

          <div className="panel">
            <div className="panel-title"><Hospital size={20} /><div><h2>Hospital Readiness</h2><small>{hospitals.length} hospitals connected</small></div></div>
            <div className="list">
              {hospitals.map(h => <div className="simple-row" key={h.id}><div><strong>{h.name}</strong><small>{h.address}</small></div><span className="beds">{h.emergency_beds} beds</span></div>)}
            </div>
          </div>
        </section>

        <section className="panel prediction-panel">
          <div className="panel-title"><Activity size={20} /><div><h2>Predictive Ambulance Placement</h2><small>Risk zones calculated from sample historical demand, traffic, weather and event inputs</small></div></div>
          <div className="prediction-grid">
            {predictions.map(p => <div className="prediction-card" key={p.id}><strong>{p.zone}</strong><span>Risk score {p.riskScore}</span><small>{p.emergency_count} emergencies · traffic {p.traffic_index}</small></div>)}
          </div>
        </section>
      </main>
    </div>
  );
}
